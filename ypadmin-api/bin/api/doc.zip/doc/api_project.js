define({
  "name": "crazyBird-ypsmallprogram",
  "version": "0.0.1",
  "description": "ypsmallprogram api",
  "title": "ypsmallprogram api",
  "url": "",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-11-15T11:01:16.431Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
